echo "Total Number of arguments: $#"
echo "First Argument: $1"
echo "Second Argument: $2"
 
