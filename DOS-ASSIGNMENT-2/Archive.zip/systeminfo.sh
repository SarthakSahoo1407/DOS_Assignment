echo "Username: `whoami`"
echo "System Name: `uname -n` "
echo "SHELL: `echo $SHELL`"
echo "PWD: `pwd`"
echo "List of file: "
echo `ls`
