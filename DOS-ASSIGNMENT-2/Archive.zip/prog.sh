cat a.txt b.txt > result.txt
sort -o result.txt result.txt
