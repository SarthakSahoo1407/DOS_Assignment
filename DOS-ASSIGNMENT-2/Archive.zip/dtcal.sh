echo "Date: `date`"
echo "Calendar : "
cal
