echo "Total number of arguments: $#"
echo "List of arguments: $@" 
